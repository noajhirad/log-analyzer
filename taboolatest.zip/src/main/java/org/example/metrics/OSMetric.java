package org.example.metrics;

import org.example.LogLine;

public class OSMetric extends Metric {

    @Override
    public void processInfo(LogLine logLine) {

        String os = logLine.getOS();

        if (os != null && !os.contains("Unknown")) {
            countsMap.put(os, countsMap.getOrDefault(os, 0) + 1);
            totalEntries++;
        }
    }

    @Override
    public void printResults() {

        System.out.println("Operating Systems:");
        super.printResults();
    }
}
